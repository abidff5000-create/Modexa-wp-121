# Modexa WP 121

একটা সাধারণ Android WebView wrapper app যেটা `web.whatsapp.com` কে **Desktop User-Agent** দিয়ে লোড করে, যাতে Desktop/QR-login mode-এ ওপেন হয়।

## Features
- Desktop mode (custom User-Agent string)
- Pull-to-refresh
- Back button → WebView history navigation
- Camera permission (QR scan) ও ফাইল-চুজার সাপোর্ট (মিডিয়া/ডকুমেন্ট পাঠানোর জন্য)
- নিজস্ব আইকন ও নাম (কোনো থার্ড-পার্টি ব্র্যান্ডিং ব্যবহার করা হয়নি)

## GitHub থেকে APK বানানো (সবচেয়ে সহজ উপায়)

এই রিপোতে একটা GitHub Actions workflow (`.github/workflows/build-apk.yml`) আছে যেটা প্রতিবার `main` ব্রাঞ্চে push করলে, বা ম্যানুয়ালি ট্রিগার করলে, অটোমেটিক APK বিল্ড করে দেয়:

1. এই পুরো ফোল্ডারটা একটা নতুন GitHub রিপোজিটরিতে push করো:
   ```bash
   cd ModexaWP
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<তোমার-ইউজারনেম>/<রিপো-নাম>.git
   git push -u origin main
   ```
2. GitHub-এ রিপোর **Actions** ট্যাবে যাও — "Build APK" workflow রান হতে দেখবে (অথবা ম্যানুয়ালি "Run workflow" বাটনে চাপো)
3. রান শেষ হলে, সেই workflow run-এর নিচে **Artifacts** সেকশনে `ModexaWP121-debug-apk` নামে zip পাবে — ডাউনলোড করে extract করলে `app-debug.apk` পাবে
4. সেই APK ফোনে ইনস্টল করো (Unknown sources/Install unknown apps অন করতে হতে পারে)

## লোকালি (Android Studio দিয়ে) বানানো
- Android Studio দিয়ে প্রজেক্ট ওপেন করো → Gradle sync হবে (প্রথমবার ইন্টারনেট লাগবে) → **Run ▶** অথবা **Build → Build APK(s)**

## নোট
- এই অ্যাপটা শুধু `web.whatsapp.com`-এর একটা wrapper — WhatsApp Inc./Meta-এর অফিসিয়াল অ্যাপ বা তাদের কোনো অফিসিয়াল প্রোডাক্ট না। নিজস্ব ব্যবহারের জন্য বানানো।
